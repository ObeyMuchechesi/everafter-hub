/* eslint-disable @next/next/no-img-element */
import { useState } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const response = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const result = await response.json();

    if (!response.ok || !result.user) {
      setError(result.error || 'Invalid credentials');
      return;
    }

    const role = result.user.role || (email.toLowerCase() === 'admin@everafter.com' ? 'admin' : 'user');
    const user = { ...result.user, role };
    localStorage.setItem('everafter_admin_user', JSON.stringify(user));

    router.push({ pathname: '/admin', query: { role: role } });
  };

  return (
    <>
      <Head>
        <title>EverAfter Hub - Login</title>
      </Head>
      <div className="login-body-wrapper">
        <div className="background-container"></div>
        
        <div className="main-container">
            <div className="right-section" style={{ margin: '0 auto' }}>
                <div className="login-card">
                    <div className="brand-header">
                        <img src="/logo.png" alt="EverAfter Hub Logo" className="brand-logo" />
                        <div className="tagline-container">
                            <span className="tagline-text">Every moment, beautifully connected</span>
                        </div>
                    </div>

                    <form className="login-form" onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label>Email Address</label>
                            <div className="input-container">
                                <span className="material-symbols-outlined input-icon">mail</span>
                                <input 
                                  type="email" 
                                  placeholder="Enter your email" 
                                  value={email} 
                                  onChange={(e) => setEmail(e.target.value)} 
                                  required 
                                />
                            </div>
                        </div>

                        <div className="form-group">
                            <label>Password</label>
                            <div className="input-container">
                                <span className="material-symbols-outlined input-icon">lock</span>
                                <input 
                                  type={showPassword ? "text" : "password"} 
                                  placeholder="Enter your password" 
                                  value={password} 
                                  onChange={(e) => setPassword(e.target.value)} 
                                  required 
                                />
                                <span 
                                  className="material-symbols-outlined password-toggle"
                                  onClick={() => setShowPassword(!showPassword)}
                                >
                                  {showPassword ? 'visibility_off' : 'visibility'}
                                </span>
                            </div>
                        </div>
                        
                        {error && <p style={{ color: '#d11f4d', fontSize: '13px', marginBottom: '16px', textAlign: 'center', background: '#fff0f3', padding: '10px', borderRadius: '6px', fontWeight: 500 }}>{error}</p>}

                        <div className="form-actions">
                            <label className="remember-me" onClick={(e) => { e.preventDefault(); setRememberMe(!rememberMe); }}>
                                <input type="checkbox" checked={rememberMe} readOnly />
                                <span className="custom-checkbox" style={{ backgroundColor: rememberMe ? 'var(--primary-color)' : 'transparent' }}>
                                    {rememberMe && <span className="material-symbols-outlined check-icon">check</span>}
                                </span>
                                Remember me
                            </label>
                        </div>

                        <button type="submit" className="sign-in-btn">
                            Sign In
                            <span className="material-symbols-outlined">arrow_forward</span>
                        </button>
                    </form>

                    <p className="brand-description" style={{ marginTop: '24px', marginBottom: '0' }}>
                        The all-in-one platform to create unforgettable<br/>
                        digital experiences for your special events.
                    </p>
                </div>
            </div>
        </div>
      </div>
    </>
  );
}
